package dev.omardiaa.transcript.core.model.payload.message.component;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import dev.omardiaa.transcript.core.util.Check;
import org.jspecify.annotations.NullMarked;

import java.util.List;

/**
 * <a href="https://docs.discord.com/developers/components/reference#action-row">Action Row</a>
 */
@NullMarked
public record ActionRow(
  int type,
  List<ActionRowChildComponent> components
) implements ContainerChildComponent {
  @JsonCreator
  public ActionRow(
    @JsonProperty(value = "type", required = true) int type,
    @JsonProperty(value = "components", required = true) List<ActionRowChildComponent> components
  ) {
    if (components.size() > 1) {
      for (ActionRowChildComponent component : components) {
        if (component instanceof SelectMenu) {
          throw new IllegalArgumentException("Action Row with a Select Menu cannot contain other components.");
        }
      }
    }

    this.type = type;
    this.components = Check.sizeMin(components, "components", 1);
  }
}
